import javax.swing.*;
import java.util.LinkedList;
import java.util.Queue;

public class Empresa {
    Queue<Pasajero> buses;

    public Empresa() {
        buses = new LinkedList<>();
    }

    public boolean isEmpty(){
        if(buses.isEmpty()){
            return true;
        }else{
            return false;
        }
    }

    public void poll()throws Exception{
        if(isEmpty()){
            throw new Exception("La cola esta vacia");


        }
        buses.poll();
    }
    public void add(Pasajero a){
        buses.add(a);
    }

    @Override
    public String toString() {
        StringBuilder st = new StringBuilder();
        for(Pasajero a: buses){
            st.append(a);
        }
        return st.toString();
    }
}
