import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

public class ventana {
    private JTextField txtNombre;
    private JTextField txtCedula;
    private JTextField txtBoletos;
    private JComboBox cbxRuta;
    private JTextArea txaMostrar;
    private JTextArea txaTotales;
    private JPanel principal;
    private JButton btnInsertar;
    private JTabbedPane tabbedPane1;
    private JTextArea txaQL;
    private JTextArea txtQG;
    private JTextArea txtQC;
    private JButton btnBoletos;
    Empresa empresa = new Empresa();
    int voletos = 20;
    int pGQ=0;
    int pQC=0;
    int pQl=0;
    float total;
    String cedulaper;


    public ventana() {
        btnInsertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = txtNombre.getText();
                String cedula = txtCedula.getText();
                String ruta = cbxRuta.getSelectedItem().toString();
                int boletos= Integer.parseInt(txtBoletos.getText());
                if(Objects.equals(cedulaper, cedula)){
                    JOptionPane.showMessageDialog(null,"no se puede comprar con la misma cedula");
                    return;
                }
                if(boletos <= 0 || boletos > 5){
                    JOptionPane.showMessageDialog(null,"NO se permiten boletos negativos");
                    return;
                }

                Pasajero pasajero= new Pasajero();
                pasajero.setCedula(cedula);
                pasajero.setNombre(nombre);
                pasajero.setRuta(ruta);
                float precio= 0;
                if (ruta == "QUITO - GUAYAQUIL"){
                    precio = (float) (boletos * 10.5);

                } else if (ruta == "QUITO - CUENCA") {
                    precio = (float) (boletos * 12.75);
                } else if (ruta == "QUITO - LOJA") {
                    precio = (float) (boletos * 15.00);
                }
                cedulaper= cedula;
                try{

                    if (ruta == "QUITO - GUAYAQUIL"){
                        if(pGQ < 20){
                            pGQ= pGQ +boletos;
                        }else {
                            JOptionPane.showMessageDialog(null,"No se puede comprar mas de 20 voletos");
                            return;
                        }

                    } else if (ruta == "QUITO - CUENCA") {

                        if(pQC < 20){
                            pQC = pQC + boletos;
                        }else{
                            JOptionPane.showMessageDialog(null,"No se puede comprar mas de 20 voletos");
                            return;
                        }

                    } else if (ruta == "QUITO - LOJA") {

                        if(pQl < 20){
                            pQl = pQl + boletos;
                        }else{
                            JOptionPane.showMessageDialog(null,"No se puede comprar mas de 20 voletos");
                            return;
                        }
                    }
                    total= total+ precio;
                    txaTotales.setText("El precio total es de: " + total );
                    empresa.add(pasajero);
                    pasajero.setVoletos(boletos);
                    txaMostrar.setText(empresa.toString()+ precio);



                } catch (Exception ex) {
                     JOptionPane.showMessageDialog(null,ex.getMessage());
                }

            }
        });
        btnBoletos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int dipQL = 20 - pQl;
                int dipQC = 20 - pQC;
                int dipQG = 20 - pGQ;

                txtQC.setText("El número de asientos disponibles es: "+ dipQC+ "\n"+ "y el número de asientos ocupados es de:" + pQC);
                txtQG.setText("El número de asientos disponibles es: "+ dipQG+ "\n"+ "y el número de asientos ocupados es de:" + pGQ);
                txaQL.setText("El número de asientos disponibles es: "+ dipQL+ "\n"+ "y el número de asientos ocupados es de:" + pQl);


            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("ventana");
        frame.setContentPane(new ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }


}
