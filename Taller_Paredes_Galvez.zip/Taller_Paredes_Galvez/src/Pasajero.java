public class Pasajero {
    private String ruta;
    private String nombre;
    private String cedula;
    private int voletos;

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public int getVoletos() {
        return voletos;
    }

    public void setVoletos(int voletos) throws Exception{
        if(voletos >5 || voletos <0){
            throw new Exception("No puede comprar mas de 5 voletos");
        }else{
            this.voletos = voletos;
        }

    }

    @Override
    public String toString() {
        return "Pasajero  "  +
                "Ruta= " + ruta  +
                ", Cantidad de boletos = " + voletos  +
                ", Nombre del pasajero= " + nombre  +
                '\n';
    }
}
